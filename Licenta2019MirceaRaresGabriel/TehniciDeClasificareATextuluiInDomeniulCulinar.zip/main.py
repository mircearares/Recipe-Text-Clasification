import copy
import os
import gensim
import matplotlib.pyplot as plt
import nltk
import pandas
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from sklearn.model_selection import RandomizedSearchCV
from sklearn.svm import LinearSVC
from sklearn.utils import shuffle
from umap import UMAP
from MySentences import MySentences
from MeanEmbeddingVectorizer import MeanEmbeddingVectorizer
from sklearn.metrics import f1_score, precision_score

PARAM_TRIALS = "param_trials.txt"


# Pasi:
# 1. Aplicam algoritmi de prelucrare a textului (BagOfWords, TFIDF, Word2Vec)
# 2. Curatam setul de date
# 3. Aplicam algoritmi de reducere a dimensionalitatii (UMAP, SVD, PCA)
# 4. Aplicam algorimtii din cealalta parte (SVC, Regr, KNN, NB, RF, DT)
# 5. Facem o clusterizare cu dupa curatarea setului de date


def compute_accuracy(prediction, cuisines):
    correct_predictions = 0
    for index in range(0, len(prediction)):
        if prediction[index] == cuisines[index]:
            correct_predictions += 1

    return (correct_predictions / len(prediction)) * 100


def print_plot(data, reducer, target, extractor):
    reduced_data = []
    if reducer == "UMAP":
        umap = UMAP(
            n_neighbors=15,
            metric='correlation'
        )
        pca = PCA(n_components=100)
        reduced_data = pca.fit_transform(data)
        reduced_data = umap.fit_transform(reduced_data)

    elif reducer == "TSNE":
        tsne = TSNE(
            perplexity=50,
            n_iter=500,
            verbose=1
        )
        pca = PCA(n_components=100)
        reduced_data = pca.fit_transform(data)
        reduced_data = tsne.fit_transform(reduced_data)

    targets = [i for i in range(0, len(target))]

    plt.scatter(reduced_data[:, 0], reduced_data[:, 1],
                c=targets, s=5, cmap='rainbow')
    plt.suptitle(reducer + " " + extractor)
    plt.show()


def prediction(train, test, classes, test_cuisines, extractor):
    accuracies = dict()
    precisions = dict()
    f1_scores = dict()

    if extractor == "TF-IDF":
        # LinearSVC
        svc_c = 0.5

        # LOGISTIC REGRESSION
        regression_c = 10

        # RANDOM FORREST
        min_samples_split = 5
        n_estimators = 1400
        max_depth = 80
        max_features = 'sqrt'
        bootstrap = False
        min_samples_leaf = 1
    elif extractor == "BOW":
        svc_c = 0.1

        # LOGISTIC REGRESSION
        regression_c = 1

        # RANDOM FORREST
        min_samples_split = 2
        n_estimators = 1400
        max_depth = 40
        max_features = 'auto'
        bootstrap = False
        min_samples_leaf = 1
    else:
        svc_c = 10

        # LOGISTIC REGRESSION
        regression_c = 1000

        # RANDOM FORREST
        min_samples_split = 2
        n_estimators = 1000
        max_depth = 50
        max_features = 'auto'
        bootstrap = False
        min_samples_leaf = 1

    classifier_svc = LinearSVC(C=svc_c)
    classifier_svc.fit(train, classes)
    prediction_svc = classifier_svc.predict(test)

    accuracies['Linear_SVC'] = compute_accuracy(prediction_svc, test_cuisines)
    precisions['Linear_SVC'] = precision_score(test_cuisines, prediction_svc, average='macro')
    f1_scores['Linear_SVC'] = f1_score(test_cuisines, prediction_svc, average='macro')

    classifier_regr = LogisticRegression(C=regression_c)
    classifier_regr.fit(train, classes)
    prediction_regr = classifier_regr.predict(test)

    accuracies['Logistic_Regression'] = compute_accuracy(prediction_regr, test_cuisines)
    precisions['Logistic_Regression'] = precision_score(test_cuisines, prediction_regr, average='macro')
    f1_scores['Logistic_Regression'] = f1_score(test_cuisines, prediction_regr, average='macro')

    classfier_rf = RandomForestClassifier(min_samples_split=min_samples_split,
                                          criterion='entropy',
                                          n_estimators=n_estimators,
                                          max_depth=max_depth,
                                          max_features=max_features,
                                          bootstrap=bootstrap,
                                          min_samples_leaf=min_samples_leaf)

    classfier_rf.fit(train, classes)
    prediction_rf = classfier_rf.predict(test)

    accuracies['Random Forrest'] = compute_accuracy(prediction_rf, test_cuisines)
    precisions['Random Forrest'] = precision_score(test_cuisines, prediction_rf, average='macro')
    f1_scores['Random Forrest'] = f1_score(test_cuisines, prediction_rf, average='macro')

    # C = [0.1, 0.15, 0.20, 0.25, 0.30, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1, 2.5, 5, 7.5]
    # random_grid = {'C': C}
    # rf = LinearSVC()
    # rf_random = RandomizedSearchCV(estimator=rf, param_distributions=random_grid, n_iter=100, cv=3,
    #                                random_state=42, n_jobs=-1)
    # rf_random.fit(train, classes)
    # print(rf_random.best_params_)

    # # Number of trees in random forest
    # n_estimators = [int(x) for x in np.linspace(start=200, stop=2000, num=10)]
    # # Number of features to consider at every split
    # max_features = ['auto', 'sqrt']
    # criterion = ['entropy']
    # # Maximum number of levels in tree
    # max_depth = [int(x) for x in np.linspace(10, 110, num=11)]
    # max_depth.append(None)
    # # Minimum number of samples required to split a node
    # min_samples_split = [2, 5, 10]
    # # Minimum number of samples required at each leaf node
    # min_samples_leaf = [1, 2, 4]
    # # Method of selecting samples for training each tree
    # bootstrap = [True, False]
    # # Create the random grid
    # random_grid = {'n_estimators': n_estimators,
    #                'max_features': max_features,
    #                'criterion': criterion,
    #                'max_depth': max_depth,
    #                'min_samples_split': min_samples_split,
    #                'min_samples_leaf': min_samples_leaf,
    #                'bootstrap': bootstrap}
    #
    # rf = RandomForestClassifier()
    # rf_random = RandomizedSearchCV(estimator=rf, param_distributions=random_grid, n_iter=100, cv=3, verbose=2,
    #                                random_state=42, n_jobs=-1)
    # rf_random.fit(train, classes)
    # print(rf_random.best_params_)

    accuracy_file = open("accuracies.txt", "w+")
    for classfier, accuracy in accuracies.items():
        print("{} : {}%".format(classfier, round(accuracy, 2)))
        print("--> precision : {}".format(precisions[classfier]))
        print("--> f1_score  : {}".format(f1_scores[classfier]))
        accuracy_file.write("{} : {}%\n".format(classfier, round(accuracy, 2)))
    accuracy_file.write("\n")


def tf_idf(train, test, cuisines, choice):

    corpus = train[choice].append(test[choice])

    vectorizer = TfidfVectorizer(
        stop_words='english', ngram_range=(1, 1), min_df=5)

    corpus_train = train[choice]
    tfidf_vect = vectorizer.fit(corpus)
    tfidf_train = tfidf_vect.transform(corpus_train)

    corpus_test = test[choice]
    tfidf_test = tfidf_vect.transform(corpus_test)

    prediction(tfidf_train.toarray(), tfidf_test.toarray(), train['cuisine'], cuisines, "TF-IDF")

    print_plot(tfidf_train.toarray(), "UMAP", train['cuisine'], "TF-IDF")
    print_plot(tfidf_train.toarray(), "TSNE", train['cuisine'], "TF-IDF")


def bag_of_words(train, test, cuisines, choice):
    vectorizer = CountVectorizer(
        stop_words='english', ngram_range=(1, 2), min_df=5)

    corpus = train[choice].append(test[choice])

    corpus_train = train[choice]
    bow_vect = vectorizer.fit(corpus)
    bow_train = bow_vect.transform(corpus_train)

    corpus_test = test[choice]
    bow_test = bow_vect.transform(corpus_test)

    prediction(bow_train, bow_test, train['cuisine'], cuisines, "BOW")

    print_plot(bow_train.toarray(), "UMAP", train['cuisine'], "Bag-Of-Words")
    print_plot(bow_train.toarray(), "TSNE", train['cuisine'], "Bag-Of-Words")


def word_2_vec(train, test, cuisines, choice):
    corpus = train[choice].append(test[choice])

    location = 'w2vmodel-' + choice

    if os.path.exists(location):
        print("Loading model")
        w2vec = gensim.models.Word2Vec.load(location)
    else:
        print("Creating model")
        w2vec = gensim.models.Word2Vec(MySentences(train[choice]),
                                       size=250,
                                       window=5,
                                       min_count=5,
                                       workers=8)
        w2vec.save(location)

    mean_embedding_vectorizer = MeanEmbeddingVectorizer(w2vec)

    corpus_train = train[choice]
    w2v_train = mean_embedding_vectorizer.transform(corpus_train)

    corpus_test = test[choice]
    w2v_test = mean_embedding_vectorizer.transform(corpus_test)

    from MeanEmbeddingVectorizer import tokenize_corpus
    tokenized_corpus = tokenize_corpus(corpus)

    prediction(w2v_train, w2v_test, train['cuisine'], cuisines, "W2V")

    print_plot(w2v_train, "UMAP", train['cuisine'], "Word-2-Vec")
    print_plot(w2v_train, "TSNE", train['cuisine'], "Word-2-Vec")


if __name__ == "__main__":
    data_set = pandas.read_json("dataset.json")

    traindf = shuffle(data_set)

    traindf['ingredients-string'] = [' , '.join(z).strip()
                                     for z in traindf['ingredients']]

    new_test = traindf[-474:]

    new_test_without_cuisine = copy.copy(new_test)
    new_test_without_cuisine.pop('cuisine')

    test_cuisines = list()
    for cuisine in new_test['cuisine']:
        test_cuisines.append(cuisine)

    new_train = traindf[:4500]

    first_input = input("Ce atribute doriti sa folositi drept instante pentru clasificare?\n"
                        "Pasii retetei? -> pasi(1)\n"
                        "Ingredientele fiecarei retete? -> ingrediente(2)\n"
                        "\n#################################################\n")

    second_input = input("Selectati algoritmul pentru extragere de trasaturi: \n"
                         "tf_idf(1) --- bag_of_words(2) --- word_2_vec(3)"
                         "\n#################################################\n")

    choice = ""
    if first_input == "1" or first_input == "pasi":
        choice = "directions"
    elif first_input == "2" or first_input == "ingrediente":
        choice = "ingredients-string"

    if choice != "":
        if second_input == "tf_idf" or second_input == "1":
            print("`````TF-IDF`````")
            tf_idf(new_train, new_test_without_cuisine, test_cuisines, choice)
        elif second_input == "bag_of_words" or second_input == "2":
            print("`````BAG-OF-WORDS`````")
            bag_of_words(new_train, new_test_without_cuisine,
                         test_cuisines, choice)
        elif second_input == "word_2_vec" or second_input == "3":
            print("`````WORD-2-VEC`````")
            word_2_vec(new_train, new_test_without_cuisine,
                       test_cuisines, choice)
    else:
        print("Eroare la input")
