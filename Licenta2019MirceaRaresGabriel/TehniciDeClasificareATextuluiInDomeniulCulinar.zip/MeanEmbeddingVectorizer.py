import numpy as np
import nltk


def tokenize_corpus(corpus):
    transformed_corpus = []
    for document in corpus:
        tokenized_doc = []
        for sent in nltk.sent_tokenize(document):
            tokenized_doc += nltk.word_tokenize(sent)
        transformed_corpus.append(np.array(tokenized_doc))
    return np.array(transformed_corpus)


class MeanEmbeddingVectorizer(object):
    def __init__(self, word2vec):
        self.word2vec = word2vec
        self.dim = len(word2vec.wv.syn0[0])

    def transform(self, corpus):
        tokenized_corpus = tokenize_corpus(corpus)

        return np.array([
            np.mean([self.word2vec.wv[w] for w in words if w in self.word2vec.wv]
                    or [np.zeros(self.dim)], axis=0)
            for words in tokenized_corpus
        ])
